# 🏛️ Site Comunidade das Nações / São Paulo

## 📋 Visão Geral

Site oficial da Comunidade das Nações em São Paulo, uma igreja moderna que integra fé e tecnologia. O projeto inclui:

- **Site institucional** com informações da igreja
- **CNTech** - Núcleo de tecnologia com trilhas de IA e Blockchain
- **Sistema de devocional diário** interativo
- **Blog dos líderes** com artigos categorizados
- **Sistema de autenticação** com Supabase
- **Painel administrativo** para gerenciamento de conteúdo
- **Sistema de roles** (administradores e usuários)

## 🚀 **SITE ONLINE**
**URL de Produção:** https://nxqiptlm.manus.space

---

## 🛠️ Tecnologias Utilizadas

### Frontend
- **React 19** - Framework principal
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Styling utilitário
- **Shadcn/UI** - Componentes de alta qualidade
- **Lucide Icons** - Ícones modernos
- **Framer Motion** - Animações

### Backend/Database
- **Supabase** - Backend as a Service
- **PostgreSQL** - Banco de dados (via Supabase)
- **Row Level Security** - Segurança de dados
- **Real-time subscriptions** - Atualizações em tempo real

### Autenticação
- **Supabase Auth** - Sistema de autenticação
- **JWT Tokens** - Autenticação stateless
- **Role-based access control** - Controle de acesso por roles

---

## 📁 Estrutura do Projeto

```
src/
├── components/
│   ├── auth/                 # Componentes de autenticação
│   │   ├── AuthModal.jsx     # Modal de login/registro
│   │   ├── LoginForm.jsx     # Formulário de login
│   │   ├── RegisterForm.jsx  # Formulário de registro
│   │   ├── ForgotPasswordForm.jsx # Recuperação de senha
│   │   └── ProtectedRoute.jsx # Proteção de rotas
│   ├── admin/                # Painel administrativo
│   │   └── AdminDashboard.jsx # Dashboard principal
│   ├── ui/                   # Componentes base (Shadcn/UI)
│   ├── DevocionalDetalhado.jsx # Devocional interativo
│   └── TrilhasCNTech.jsx     # Trilhas de aprendizado
├── contexts/
│   └── AuthContext.jsx       # Contexto de autenticação
├── lib/
│   └── supabase.js          # Configuração e funções do Supabase
├── assets/                   # Imagens e recursos
└── App.jsx                  # Componente principal
```

---

## 🔧 Configuração para Desenvolvimento

### 1. Pré-requisitos
- Node.js 18+ 
- npm ou pnpm
- Conta no Supabase

### 2. Clonagem e Instalação
```bash
# Clonar o repositório
git clone <url-do-repositorio>
cd comunidade-nacoes-site

# Instalar dependências
pnpm install
# ou
npm install
```

### 3. Configuração do Supabase

#### 3.1 Criar Projeto no Supabase
1. Acesse [supabase.com](https://supabase.com)
2. Crie uma nova conta ou faça login
3. Clique em "New Project"
4. Escolha uma organização
5. Configure:
   - **Name:** comunidade-nacoes
   - **Database Password:** (senha segura)
   - **Region:** South America (São Paulo)
6. Aguarde a criação do projeto

#### 3.2 Configurar Variáveis de Ambiente
```bash
# Copiar arquivo de exemplo
cp .env.example .env

# Editar .env com suas credenciais
VITE_SUPABASE_URL=https://seu-projeto-id.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anonima
```

**Para encontrar suas credenciais:**
1. No dashboard do Supabase, vá em **Settings > API**
2. Copie a **URL** e **anon public key**

### 4. Configuração do Banco de Dados

Execute os seguintes comandos SQL no **SQL Editor** do Supabase:

#### 4.1 Criar Tabela de Perfis
```sql
-- Criar tabela de perfis de usuário
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT,
  full_name TEXT,
  phone TEXT,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS (Row Level Security)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Política para usuários verem apenas seu próprio perfil
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

-- Política para usuários atualizarem apenas seu próprio perfil
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

-- Política para admins verem todos os perfis
CREATE POLICY "Admins can view all profiles" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Política para admins atualizarem qualquer perfil
CREATE POLICY "Admins can update any profile" ON profiles
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Função para criar perfil automaticamente
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para criar perfil quando usuário se registra
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```

#### 4.2 Criar Tabela de Posts do Blog
```sql
-- Criar tabela de posts do blog
CREATE TABLE blog_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  category TEXT DEFAULT 'geral',
  author_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  published BOOLEAN DEFAULT false,
  featured_image TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- Política para todos verem posts publicados
CREATE POLICY "Anyone can view published posts" ON blog_posts
  FOR SELECT USING (published = true);

-- Política para autores verem seus próprios posts
CREATE POLICY "Authors can view own posts" ON blog_posts
  FOR SELECT USING (auth.uid() = author_id);

-- Política para admins verem todos os posts
CREATE POLICY "Admins can view all posts" ON blog_posts
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Política para usuários autenticados criarem posts
CREATE POLICY "Authenticated users can create posts" ON blog_posts
  FOR INSERT WITH CHECK (auth.uid() = author_id);

-- Política para autores editarem seus posts
CREATE POLICY "Authors can update own posts" ON blog_posts
  FOR UPDATE USING (auth.uid() = author_id);

-- Política para admins editarem qualquer post
CREATE POLICY "Admins can update any post" ON blog_posts
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
```

#### 4.3 Criar Tabela de Eventos
```sql
-- Criar tabela de eventos
CREATE TABLE events (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  event_date TIMESTAMP WITH TIME ZONE NOT NULL,
  location TEXT,
  category TEXT DEFAULT 'geral',
  max_participants INTEGER,
  created_by UUID REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS
ALTER TABLE events ENABLE ROW LEVEL SECURITY;

-- Política para todos verem eventos
CREATE POLICY "Anyone can view events" ON events FOR SELECT USING (true);

-- Política para admins gerenciarem eventos
CREATE POLICY "Admins can manage events" ON events
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
```

#### 4.4 Criar Tabela de Devocionais
```sql
-- Criar tabela de devocionais
CREATE TABLE devotionals (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL UNIQUE,
  title TEXT NOT NULL,
  verse TEXT NOT NULL,
  reference TEXT NOT NULL,
  prayer TEXT NOT NULL,
  reading TEXT NOT NULL,
  reflection TEXT NOT NULL,
  song_title TEXT,
  song_artist TEXT,
  song_lyrics TEXT,
  created_by UUID REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Habilitar RLS
ALTER TABLE devotionals ENABLE ROW LEVEL SECURITY;

-- Política para todos verem devocionais
CREATE POLICY "Anyone can view devotionals" ON devotionals FOR SELECT USING (true);

-- Política para admins gerenciarem devocionais
CREATE POLICY "Admins can manage devotionals" ON devotionals
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
```

#### 4.5 Criar Primeiro Usuário Admin
```sql
-- Após criar sua conta no site, execute este comando substituindo pelo seu email
UPDATE profiles 
SET role = 'admin' 
WHERE email = 'seu-email@exemplo.com';
```

### 5. Executar o Projeto
```bash
# Modo desenvolvimento
pnpm dev
# ou
npm run dev

# Acessar em http://localhost:5173
```

---

## 🔐 Sistema de Autenticação

### Roles de Usuário
- **user** - Usuário comum (padrão)
- **admin** - Administrador com acesso total

### Funcionalidades Implementadas
- ✅ Login/Logout
- ✅ Registro de usuários
- ✅ Recuperação de senha
- ✅ Proteção de rotas
- ✅ Painel administrativo
- ✅ Gerenciamento de roles
- ✅ Contexto global de autenticação

### Componentes de Autenticação
- `AuthContext` - Contexto global
- `AuthModal` - Modal de login/registro
- `ProtectedRoute` - Proteção de rotas
- `AdminDashboard` - Painel administrativo

---

## 📱 Funcionalidades Principais

### 1. Site Institucional
- Hero section com call-to-actions
- Seção "Sobre Nós"
- Informações de contato
- Design responsivo

### 2. CNTech - Núcleo de Tecnologia
- **4 Trilhas de Aprendizado:**
  - IA para Iniciantes (12 meses)
  - IA Avançada (6 meses)
  - Blockchain Básico (8 meses)
  - Desenvolvimento Blockchain (10 meses)
- Conteúdo detalhado para cada trilha
- Sistema de inscrições (futuro)

### 3. Devocional Diário
- **4 elementos estruturados:**
  - 🙏 Oração guiada
  - 📖 Leitura bíblica
  - 💡 Reflexão e estudo
  - 🎵 Música inspiradora
- Interface interativa
- Espaço para anotações pessoais

### 4. Blog dos Líderes
- Artigos categorizados
- Sistema de autoria
- Interface de leitura otimizada

### 5. Sistema de Eventos
- Calendário de eventos
- Categorização por tipo
- Informações detalhadas

---

## 🎨 Design System

### Paleta de Cores
```css
/* Cores principais */
--blue-900: #1E3A8A    /* Azul profundo - confiança */
--blue-600: #3B82F6    /* Azul claro - tecnologia */
--purple-600: #8B5CF6  /* Roxo - espiritualidade */
--yellow-500: #F59E0B  /* Dourado - destaque */

/* Cores de status */
--green-600: #16A34A   /* Sucesso */
--red-600: #DC2626     /* Erro */
--orange-600: #EA580C  /* Aviso */
```

### Tipografia
- **Títulos:** Inter/Poppins
- **Corpo:** Open Sans
- **Código:** JetBrains Mono

### Componentes
- Baseados em Shadcn/UI
- Totalmente customizáveis
- Acessibilidade incluída

---

## 🚀 Deploy e Produção

### Build para Produção
```bash
# Gerar build otimizado
pnpm build

# Preview do build
pnpm preview
```

### Deploy Automático
O projeto está configurado para deploy automático. Qualquer push para a branch main será automaticamente deployado.

**URL de Produção:** https://nxqiptlm.manus.space

---

## 📝 Próximos Passos

### Funcionalidades Planejadas
1. **Sistema de Inscrições** nas trilhas CNTech
2. **Pagamentos** integrados (Stripe/PagSeguro)
3. **CMS** para gerenciar conteúdo
4. **Notificações** push
5. **App Mobile** (React Native)
6. **Sistema de Comentários** no blog
7. **Integração** com redes sociais
8. **Analytics** e métricas

### Melhorias Técnicas
1. **Testes** automatizados (Jest/Cypress)
2. **CI/CD** pipeline
3. **Monitoramento** de erros (Sentry)
4. **Performance** optimization
5. **SEO** avançado
6. **PWA** features

---

## 🤝 Contribuição

### Workflow de Desenvolvimento
1. Criar branch para feature: `git checkout -b feature/nova-funcionalidade`
2. Fazer commits descritivos
3. Abrir Pull Request
4. Code review
5. Merge após aprovação

### Padrões de Código
- **ESLint** para linting
- **Prettier** para formatação
- **Conventional Commits** para mensagens
- **TypeScript** (futuro)

---

## 📞 Suporte

### Contatos
- **Email:** contato@comunidadedasnacoes.org.br
- **Telefone:** (11) 3456-7890
- **Endereço:** Rua das Nações, 123 - Vila Madalena, SP

### Documentação Adicional
- [Supabase Docs](https://supabase.com/docs)
- [React Docs](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [Shadcn/UI](https://ui.shadcn.com)

---

**Desenvolvido com ❤️ para a Comunidade das Nações**

