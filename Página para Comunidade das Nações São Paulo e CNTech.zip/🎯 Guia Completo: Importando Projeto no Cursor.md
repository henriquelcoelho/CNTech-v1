# 🎯 Guia Completo: Importando Projeto no Cursor

## 📋 Visão Geral

Este guia te ajudará a importar o projeto da **Comunidade das Nações** no **Cursor** e continuar o desenvolvimento com todas as funcionalidades de IA integradas.

---

## 🚀 Passo 1: Preparação do Ambiente

### 1.1 Download dos Arquivos
Você precisa baixar todos os arquivos do projeto que estão no sandbox:

**Localização do projeto:** `/home/ubuntu/projeto_site_igreja/comunidade-nacoes-site/`

**Arquivos principais para download:**
```
comunidade-nacoes-site/
├── src/
├── public/
├── package.json
├── vite.config.js
├── tailwind.config.js
├── .env.example
├── README.md
└── index.html
```

### 1.2 Ferramentas Necessárias
- **Cursor** (baixar em cursor.sh)
- **Node.js 18+** 
- **Git**
- **pnpm** (recomendado) ou npm

---

## 🔧 Passo 2: Configuração Local

### 2.1 Criar Repositório Git
```bash
# Criar novo repositório
mkdir comunidade-nacoes-site
cd comunidade-nacoes-site
git init

# Adicionar arquivos baixados
# (copie todos os arquivos do sandbox para esta pasta)

# Primeiro commit
git add .
git commit -m "feat: initial commit - site comunidade das nações"
```

### 2.2 Instalar Dependências
```bash
# Instalar dependências
pnpm install
# ou
npm install

# Verificar se tudo está funcionando
pnpm dev
```

---

## 🏗️ Passo 3: Configuração do Supabase

### 3.1 Criar Projeto Supabase
1. Acesse [supabase.com](https://supabase.com)
2. Crie conta ou faça login
3. **New Project**:
   - **Name:** comunidade-nacoes
   - **Password:** (senha forte)
   - **Region:** South America (São Paulo)

### 3.2 Configurar Variáveis de Ambiente
```bash
# Copiar arquivo de exemplo
cp .env.example .env

# Editar .env (use Cursor para editar)
VITE_SUPABASE_URL=https://seu-projeto-id.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anonima-aqui
```

**Para encontrar as credenciais:**
- Dashboard Supabase → **Settings** → **API**
- Copie **URL** e **anon public key**

### 3.3 Configurar Banco de Dados
No **SQL Editor** do Supabase, execute os comandos do README.md:

1. **Tabela de perfis** (profiles)
2. **Tabela de posts** (blog_posts)  
3. **Tabela de eventos** (events)
4. **Tabela de devocionais** (devotionals)
5. **Políticas de segurança** (RLS)
6. **Triggers** automáticos

### 3.4 Criar Primeiro Admin
```sql
-- Após se registrar no site, execute:
UPDATE profiles 
SET role = 'admin' 
WHERE email = 'seu-email@exemplo.com';
```

---

## 🎨 Passo 4: Abrindo no Cursor

### 4.1 Abrir Projeto
```bash
# Abrir pasta no Cursor
cursor .

# Ou pelo menu: File → Open Folder
```

### 4.2 Configurações Recomendadas do Cursor

#### Extensões Úteis:
- **ES7+ React/Redux/React-Native snippets**
- **Tailwind CSS IntelliSense**
- **Auto Rename Tag**
- **Bracket Pair Colorizer**
- **GitLens**

#### Settings.json do Cursor:
```json
{
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "emmet.includeLanguages": {
    "javascript": "javascriptreact"
  },
  "tailwindCSS.experimental.classRegex": [
    ["clsx\\(([^)]*)\\)", "(?:'|\"|`)([^']*)(?:'|\"|`)"]
  ]
}
```

---

## 🤖 Passo 5: Usando IA do Cursor

### 5.1 Comandos Úteis da IA

#### Para Desenvolvimento:
```
Ctrl+K (Cmd+K no Mac) - Editar código com IA
Ctrl+L (Cmd+L no Mac) - Chat com IA
```

#### Prompts Úteis:
```
"Adicione validação de formulário neste componente"
"Crie um hook customizado para gerenciar estado do modal"
"Otimize este componente para performance"
"Adicione testes unitários para esta função"
"Refatore este código para usar TypeScript"
```

### 5.2 Contexto do Projeto para IA

**Cole este contexto quando usar a IA:**
```
Este é um projeto React para uma igreja que integra fé e tecnologia:

TECNOLOGIAS:
- React 19 + Vite
- Tailwind CSS + Shadcn/UI
- Supabase (auth + database)
- Sistema de roles (admin/user)

ESTRUTURA:
- Site institucional
- CNTech (trilhas de IA/Blockchain)
- Devocional diário interativo
- Blog dos líderes
- Painel administrativo

PADRÕES:
- Componentes funcionais com hooks
- Context API para estado global
- Protected routes por role
- Design responsivo mobile-first
```

---

## 📁 Passo 6: Estrutura de Desenvolvimento

### 6.1 Organização de Arquivos
```
src/
├── components/
│   ├── auth/           # Autenticação
│   ├── admin/          # Painel admin
│   ├── ui/             # Componentes base
│   └── ...
├── contexts/           # Contextos React
├── lib/               # Utilitários
├── hooks/             # Hooks customizados
├── utils/             # Funções auxiliares
└── types/             # TypeScript types (futuro)
```

### 6.2 Convenções de Nomenclatura
- **Componentes:** PascalCase (`AuthModal.jsx`)
- **Hooks:** camelCase com "use" (`useAuth.js`)
- **Utilitários:** camelCase (`formatDate.js`)
- **Constantes:** UPPER_SNAKE_CASE (`USER_ROLES`)

---

## 🔄 Passo 7: Workflow de Desenvolvimento

### 7.1 Comandos Essenciais
```bash
# Desenvolvimento
pnpm dev              # Servidor local
pnpm build           # Build produção
pnpm preview         # Preview do build
pnpm lint            # Verificar código

# Git
git add .
git commit -m "feat: nova funcionalidade"
git push origin main
```

### 7.2 Branches Recomendadas
```bash
main                 # Produção
develop             # Desenvolvimento
feature/nome        # Novas funcionalidades
hotfix/nome         # Correções urgentes
```

---

## 🎯 Passo 8: Próximas Funcionalidades

### 8.1 Prioridades Imediatas
1. **Sistema de Inscrições** nas trilhas CNTech
2. **CMS** para gerenciar blog e devocionais
3. **Notificações** em tempo real
4. **Sistema de Pagamentos**

### 8.2 Usando IA para Desenvolvimento

#### Exemplo: Criar Sistema de Inscrições
```
Prompt para IA:
"Crie um sistema de inscrições para as trilhas CNTech que inclui:
- Formulário de inscrição com dados pessoais
- Seleção de trilha e forma de pagamento
- Integração com Supabase
- Email de confirmação
- Painel admin para gerenciar inscrições"
```

#### Exemplo: Melhorar Performance
```
Prompt para IA:
"Analise este componente e sugira otimizações:
- Lazy loading de componentes
- Memoização onde necessário
- Code splitting
- Otimização de imagens"
```

---

## 🛠️ Passo 9: Debugging e Troubleshooting

### 9.1 Problemas Comuns

#### Erro de Supabase Connection:
```bash
# Verificar .env
cat .env

# Testar conexão
pnpm dev
# Abrir console do navegador
```

#### Erro de Dependências:
```bash
# Limpar cache
rm -rf node_modules package-lock.json
pnpm install

# Ou usar npm
rm -rf node_modules package-lock.json
npm install
```

### 9.2 Logs Úteis
```javascript
// Debug de autenticação
console.log('User:', user)
console.log('Profile:', profile)
console.log('Is Admin:', isAdmin)

// Debug de Supabase
console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL)
```

---

## 📚 Passo 10: Recursos e Documentação

### 10.1 Links Importantes
- **Supabase Docs:** https://supabase.com/docs
- **React Docs:** https://react.dev
- **Tailwind CSS:** https://tailwindcss.com
- **Shadcn/UI:** https://ui.shadcn.com
- **Cursor Docs:** https://cursor.sh/docs

### 10.2 Comunidades
- **Discord Supabase:** https://discord.supabase.com
- **Reddit React:** r/reactjs
- **Stack Overflow:** tag [reactjs] [supabase]

---

## ✅ Checklist Final

### Antes de Começar:
- [ ] Cursor instalado e configurado
- [ ] Node.js 18+ instalado
- [ ] Projeto baixado do sandbox
- [ ] Conta Supabase criada
- [ ] Banco de dados configurado
- [ ] Variáveis de ambiente definidas
- [ ] Dependências instaladas
- [ ] Servidor local funcionando

### Primeiro Desenvolvimento:
- [ ] Fazer primeiro commit
- [ ] Testar autenticação
- [ ] Acessar painel admin
- [ ] Verificar todas as seções
- [ ] Testar responsividade

---

## 🎉 Pronto para Desenvolver!

Agora você tem tudo configurado para continuar o desenvolvimento no Cursor com:

✅ **Projeto completo** funcionando  
✅ **Supabase** configurado  
✅ **Sistema de autenticação** ativo  
✅ **Painel administrativo** operacional  
✅ **IA do Cursor** pronta para ajudar  

**Dica:** Use a IA do Cursor para acelerar o desenvolvimento. Ela entende o contexto do projeto e pode ajudar com código, debugging e novas funcionalidades!

---

**Bom desenvolvimento! 🚀**

