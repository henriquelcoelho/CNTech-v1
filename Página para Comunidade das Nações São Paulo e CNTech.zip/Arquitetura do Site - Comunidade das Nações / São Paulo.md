# Arquitetura do Site - Comunidade das Nações / São Paulo

## Estrutura de Navegação

### Menu Principal
```
[LOGO] Comunidade das Nações
├── Início
├── Sobre Nós
├── CNTech ⭐
├── Devocional
├── Blog dos Líderes
├── Eventos
└── Contato
```

### Menu CNTech (Submenu)
```
CNTech
├── Trilhas de Aprendizado
│   ├── IA para Iniciantes
│   ├── IA Avançada
│   ├── Blockchain Básico
│   └── Desenvolvimento Blockchain
├── Notícias & Tendências
├── Podcasts
├── Eventos Internos
└── Recursos
```

## Wireframes das Páginas

### 1. Página Inicial (Home)

```
┌─────────────────────────────────────────────────────────────┐
│ [LOGO] Comunidade das Nações    [Menu Principal]    [CNTech]│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           HERO SECTION                                      │
│     [Imagem/Vídeo da Igreja]                               │
│                                                             │
│     "Bem-vindos à Comunidade das Nações"                   │
│     "Fé, Tecnologia e Comunidade em São Paulo"             │
│                                                             │
│     [Conheça-nos] [CNTech] [Devocional Hoje]              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           SEÇÃO BOAS-VINDAS                                 │
│                                                             │
│  [Imagem Pastor]    "Nossa igreja é um lugar onde a fé     │
│                     encontra a inovação. Somos uma         │
│                     comunidade que abraça tanto as         │
│                     tradições cristãs quanto as            │
│                     tecnologias emergentes..."             │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           DESTAQUE CNTECH                                   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 🤖 CNTech - Núcleo de Tecnologia                   │   │
│  │                                                     │   │
│  │ Trilhas de aprendizado em IA e Blockchain          │   │
│  │ Podcasts, eventos e recursos educativos            │   │
│  │                                                     │   │
│  │ [Explorar CNTech]                                   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           DEVOCIONAL DO DIA                                 │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 📖 Devocional de Hoje                               │   │
│  │                                                     │   │
│  │ "Versículo do dia..."                               │   │
│  │ Tema: [Tema do estudo]                              │   │
│  │                                                     │   │
│  │ [Ler Devocional] [Ouvir Áudio]                      │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           BLOG DOS LÍDERES                                  │
│                                                             │
│  [Card 1]    [Card 2]    [Card 3]                         │
│  [Imagem]    [Imagem]    [Imagem]                         │
│  Título      Título      Título                            │
│  Resumo      Resumo      Resumo                            │
│  [Ler mais]  [Ler mais]  [Ler mais]                       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           PRÓXIMOS EVENTOS                                  │
│                                                             │
│  📅 Dom 15/07 - Culto de Celebração                       │
│  🎓 Qua 18/07 - Workshop IA para Iniciantes               │
│  🎙️ Sex 20/07 - Podcast CNTech ao vivo                    │
│                                                             │
│  [Ver todos os eventos]                                     │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           FOOTER                                            │
│  [Contato] [Localização] [Redes Sociais] [Newsletter]     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 2. Página CNTech

```
┌─────────────────────────────────────────────────────────────┐
│ [LOGO] Comunidade das Nações    [Menu Principal]    [CNTech]│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           HERO CNTECH                                       │
│     [Background tecnológico]                               │
│                                                             │
│     🤖 CNTech - Núcleo de Tecnologia                       │
│     "Fé e Inovação: Explorando IA e Blockchain"           │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           TRILHAS DE APRENDIZADO                            │
│                                                             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐│
│  │ 🧠 IA       │ │ 🚀 IA       │ │ ⛓️ Blockchain│ │ 💻 Dev  ││
│  │ Iniciante   │ │ Avançada    │ │ Básico      │ │ Blockchain││
│  │             │ │             │ │             │ │         ││
│  │ 12 meses    │ │ 6 meses     │ │ 8 meses     │ │ 10 meses││
│  │ [Começar]   │ │ [Começar]   │ │ [Começar]   │ │ [Começar]││
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘│
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           NOTÍCIAS & TENDÊNCIAS                             │
│                                                             │
│  📰 Últimas Notícias                                       │
│                                                             │
│  [Card Notícia 1] [Card Notícia 2] [Card Notícia 3]       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           PODCASTS                                          │
│                                                             │
│  🎙️ Tech & Fé - Episódios Recentes                        │
│                                                             │
│  ▶️ [Player de Podcast Integrado]                          │
│                                                             │
│  📋 Lista de Episódios                                     │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           EVENTOS INTERNOS                                  │
│                                                             │
│  📅 Próximos Eventos CNTech                                │
│                                                             │
│  • Workshop IA - 18/07                                     │
│  • Hackathon Cristão - 25/07                              │
│  • Palestra Blockchain - 02/08                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 3. Página Devocional

```
┌─────────────────────────────────────────────────────────────┐
│ [LOGO] Comunidade das Nações    [Menu Principal]    [CNTech]│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           DEVOCIONAL DIÁRIO                                 │
│                                                             │
│  📅 [Seletor de Data] ← → [Hoje: 13/07/2025]              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           VERSÍCULO DO DIA                                  │
│                                                             │
│  "Porque eu bem sei os pensamentos que tenho a vosso       │
│   respeito, diz o Senhor; pensamentos de paz e não de      │
│   mal, para vos dar o fim que esperais."                   │
│                                                             │
│   - Jeremias 29:11                                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           SEÇÕES DO DEVOCIONAL                              │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 🙏 MOMENTO DE ORAÇÃO                                │   │
│  │                                                     │   │
│  │ [Texto guiado para oração]                          │   │
│  │ [Espaço para anotações pessoais]                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 📖 LEITURA BÍBLICA                                  │   │
│  │                                                     │   │
│  │ Capítulo: Jeremias 29                              │   │
│  │ [Texto completo do capítulo]                        │   │
│  │ [🔊 Ouvir áudio]                                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 💡 ENTENDIMENTO                                     │   │
│  │                                                     │   │
│  │ [Explicação do contexto]                            │   │
│  │ [Principais ensinamentos]                           │   │
│  │ [Aplicação prática]                                 │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ 🎵 MÚSICA INSPIRADORA                               │   │
│  │                                                     │   │
│  │ "Planos de Esperança" - Fernandinho                │   │
│  │ ▶️ [Player de música]                               │   │
│  │ [Letra da música]                                   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           NAVEGAÇÃO                                         │
│                                                             │
│  [← Devocional Anterior] [Histórico] [Próximo Devocional →]│
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 4. Blog dos Líderes

```
┌─────────────────────────────────────────────────────────────┐
│ [LOGO] Comunidade das Nações    [Menu Principal]    [CNTech]│
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           BLOG DOS LÍDERES                                  │
│                                                             │
│  ✍️ Reflexões e Ensinamentos da Liderança                  │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           ARTIGO EM DESTAQUE                                │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ [Imagem do artigo]                                  │   │
│  │                                                     │   │
│  │ "A Igreja na Era Digital: Desafios e Oportunidades"│   │
│  │                                                     │   │
│  │ Por Pastor João Silva - 10/07/2025                 │   │
│  │                                                     │   │
│  │ [Resumo do artigo...]                               │   │
│  │                                                     │   │
│  │ [Ler artigo completo]                               │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           ARTIGOS RECENTES                                  │
│                                                             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │
│  │ [Imagem]    │ │ [Imagem]    │ │ [Imagem]    │           │
│  │ Título      │ │ Título      │ │ Título      │           │
│  │ Autor       │ │ Autor       │ │ Autor       │           │
│  │ Data        │ │ Data        │ │ Data        │           │
│  │ [Ler mais]  │ │ [Ler mais]  │ │ [Ler mais]  │           │
│  └─────────────┘ └─────────────┘ └─────────────┘           │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           CATEGORIAS                                        │
│                                                             │
│  📚 Todas | 🙏 Espiritualidade | 💻 Tecnologia |           │
│  👥 Comunidade | 📖 Estudos Bíblicos                       │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           PAGINAÇÃO                                         │
│                                                             │
│  [← Anterior] [1] [2] [3] [4] [5] [Próximo →]              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Arquitetura de Informação

### Hierarquia de Conteúdo

```
Site Comunidade das Nações
│
├── 1. Página Inicial
│   ├── Hero Section
│   ├── Boas-vindas
│   ├── Destaque CNTech
│   ├── Devocional do Dia
│   ├── Blog dos Líderes (preview)
│   └── Próximos Eventos
│
├── 2. Sobre Nós
│   ├── História da Igreja
│   ├── Missão e Visão
│   ├── Liderança
│   └── Localização
│
├── 3. CNTech
│   ├── 3.1 Trilhas de Aprendizado
│   │   ├── IA para Iniciantes
│   │   ├── IA Avançada
│   │   ├── Blockchain Básico
│   │   └── Desenvolvimento Blockchain
│   ├── 3.2 Notícias & Tendências
│   ├── 3.3 Podcasts
│   ├── 3.4 Eventos Internos
│   └── 3.5 Recursos
│
├── 4. Devocional
│   ├── Devocional do Dia
│   ├── Histórico de Devocionais
│   ├── Plano de Leitura Anual
│   └── Músicas Inspiradoras
│
├── 5. Blog dos Líderes
│   ├── Artigos por Categoria
│   ├── Artigos por Autor
│   ├── Arquivo por Data
│   └── Busca
│
├── 6. Eventos
│   ├── Calendário
│   ├── Eventos Regulares
│   ├── Eventos Especiais
│   └── Inscrições
│
└── 7. Contato
    ├── Formulário de Contato
    ├── Localização
    ├── Horários de Funcionamento
    └── Redes Sociais
```

### Fluxo de Navegação do Usuário

#### Usuário Interessado em Tecnologia
```
Página Inicial → CNTech → Trilhas de Aprendizado → Inscrição
```

#### Membro da Igreja
```
Página Inicial → Devocional → Leitura do Dia → Compartilhamento
```

#### Visitante Novo
```
Página Inicial → Sobre Nós → Eventos → Contato
```

#### Leitor do Blog
```
Página Inicial → Blog dos Líderes → Artigo → Comentários
```

## Funcionalidades Especiais

### Sistema de Busca
- Busca global no site
- Filtros por categoria
- Busca em devocionais por data/tema
- Busca em artigos do blog

### Sistema de Notificações
- Newsletter semanal
- Alertas de novos devocionais
- Notificações de eventos CNTech
- Updates do blog dos líderes

### Integração com Redes Sociais
- Compartilhamento de devocionais
- Compartilhamento de artigos
- Feed do Instagram da igreja
- Links para podcasts

### Área Administrativa (Futuro)
- Gerenciamento de conteúdo
- Estatísticas de acesso
- Gestão de eventos
- Moderação de comentários

