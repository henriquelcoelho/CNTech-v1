# Conceito de Design - Site Comunidade das Nações / São Paulo

## Visão Geral
O site da Comunidade das Nações / São Paulo deve refletir uma igreja moderna, acolhedora e tecnologicamente avançada, especialmente através da seção CNTech. O design deve equilibrar tradição cristã com inovação tecnológica.

## Paleta de Cores

### Cores Primárias
- **Azul Profundo (#1E3A8A)** - Confiança, estabilidade, fé
- **Azul Claro (#3B82F6)** - Tecnologia, inovação, modernidade
- **Branco (#FFFFFF)** - Pureza, paz, clareza

### Cores Secundárias
- **Dourado (#F59E0B)** - Divindade, sabedoria, destaque
- **Cinza Claro (#F3F4F6)** - Neutralidade, elegância
- **Verde (#10B981)** - Crescimento, esperança, vida

### Cores de Apoio
- **Roxo (#8B5CF6)** - Espiritualidade, criatividade
- **Laranja (#F97316)** - Energia, entusiasmo

## Tipografia

### Fonte Principal - Títulos
**Inter** ou **Poppins**
- Moderna e legível
- Boa para títulos e destaques
- Tamanhos: 48px (H1), 36px (H2), 24px (H3)

### Fonte Secundária - Corpo
**Open Sans** ou **Source Sans Pro**
- Excelente legibilidade
- Ideal para textos longos
- Tamanhos: 18px (corpo), 16px (secundário), 14px (legendas)

## Layout e Estrutura

### Header
- Logo da igreja (lado esquerdo)
- Menu de navegação horizontal
- Botão de destaque "CNTech" com ícone
- Design responsivo com menu hambúrguer no mobile

### Hero Section
- Imagem/vídeo de fundo da igreja
- Título principal sobreposto
- Subtítulo explicativo
- Call-to-action buttons
- Altura: 70vh

### Seções Principais
1. **Boas-vindas** - Texto acolhedor com imagem da comunidade
2. **CNTech** - Destaque especial com ícones de tecnologia
3. **Devocional Diário** - Card interativo com versículo do dia
4. **Blog dos Líderes** - Grid de artigos recentes
5. **Eventos** - Calendário visual
6. **Contato** - Formulário e localização

## Elementos Visuais

### Ícones
- **IA**: Cérebro com circuitos, chip neural
- **Blockchain**: Blocos conectados, rede distribuída
- **Tecnologia**: Engrenagens, código, dispositivos
- **Igreja**: Cruz, mãos em oração, Bíblia
- **Comunidade**: Pessoas conectadas, coração

### Imagens
- **Estilo**: Fotografias reais da comunidade
- **Tratamento**: Filtros suaves, cores vibrantes
- **Formato**: Responsivo, otimizado para web

### Cards e Componentes
- **Bordas**: Arredondadas (8px radius)
- **Sombras**: Sutis (box-shadow: 0 4px 6px rgba(0,0,0,0.1))
- **Hover**: Elevação suave e mudança de cor
- **Transições**: 0.3s ease-in-out

## Seção CNTech - Design Especial

### Identidade Visual
- **Cor principal**: Gradiente azul-roxo
- **Ícones**: Estilo outline com preenchimento em hover
- **Background**: Padrão sutil de circuitos ou hexágonos

### Layout CNTech
1. **Header da seção** - Logo CNTech + tagline
2. **Trilhas de aprendizado** - Cards interativos
3. **Notícias** - Feed dinâmico
4. **Podcasts** - Player integrado
5. **Eventos** - Timeline visual

## Responsividade

### Desktop (1200px+)
- Layout em grid de 12 colunas
- Sidebar para navegação secundária
- Imagens em alta resolução

### Tablet (768px - 1199px)
- Layout adaptado para 2 colunas
- Menu colapsável
- Imagens otimizadas

### Mobile (< 768px)
- Layout single-column
- Menu hambúrguer
- Botões touch-friendly (44px mínimo)
- Imagens responsivas

## Acessibilidade

### Contraste
- Ratio mínimo 4.5:1 para texto normal
- Ratio mínimo 3:1 para texto grande

### Navegação
- Foco visível em todos os elementos interativos
- Navegação por teclado
- Alt text em todas as imagens

### Semântica
- HTML semântico correto
- ARIA labels quando necessário
- Estrutura hierárquica clara

## Funcionalidades Interativas

### Animações
- **Scroll reveal** - Elementos aparecem ao rolar
- **Hover effects** - Mudanças sutis em botões e cards
- **Loading states** - Indicadores visuais

### Microinterações
- **Botões**: Feedback visual ao clicar
- **Formulários**: Validação em tempo real
- **Menu**: Transições suaves

## Mood e Tom

### Personalidade da Marca
- **Acolhedora**: Cores quentes, imagens de comunidade
- **Moderna**: Design limpo, tecnologia integrada
- **Confiável**: Tipografia clara, layout organizado
- **Inspiradora**: Imagens motivacionais, mensagens positivas

### Linguagem Visual
- **Minimalista**: Espaços em branco generosos
- **Profissional**: Alinhamento preciso, grid consistente
- **Humana**: Fotografias reais, não stock photos
- **Tecnológica**: Elementos digitais sutis, ícones modernos

## Especificações Técnicas

### Performance
- **Tempo de carregamento**: < 3 segundos
- **Otimização de imagens**: WebP quando possível
- **Lazy loading**: Para imagens abaixo da dobra

### SEO
- **Meta tags** otimizadas
- **Schema markup** para eventos e artigos
- **URLs amigáveis**
- **Sitemap XML**

### Compatibilidade
- **Browsers**: Chrome, Firefox, Safari, Edge (últimas 2 versões)
- **Dispositivos**: Desktop, tablet, smartphone
- **Sistemas**: Windows, macOS, iOS, Android

